For the pre-processed dataset, refer to the following Google Drive link:

https://drive.google.com/drive/folders/1YqWrLS2YIiAf7lYjG7Xct-ueoiJrYqt-?usp=sharing